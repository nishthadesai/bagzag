package com.hyperlink.flutter_demo_structure

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
