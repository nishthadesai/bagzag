// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Flutter Demo Structure`
  String get applicationTitle {
    return Intl.message(
      'Flutter Demo Structure',
      name: 'applicationTitle',
      desc: '',
      args: [],
    );
  }

  /// `The connection has timed out. Please try again`
  String get connectionTimedOut {
    return Intl.message(
      'The connection has timed out. Please try again',
      name: 'connectionTimedOut',
      desc: '',
      args: [],
    );
  }

  /// `There are some problems with the connection. Please try again`
  String get connectionProblem {
    return Intl.message(
      'There are some problems with the connection. Please try again',
      name: 'connectionProblem',
      desc: '',
      args: [],
    );
  }

  /// `Invalid credentials`
  String get invalidCredentials {
    return Intl.message(
      'Invalid credentials',
      name: 'invalidCredentials',
      desc: '',
      args: [],
    );
  }

  /// `Response is null`
  String get responseNull {
    return Intl.message(
      'Response is null',
      name: 'responseNull',
      desc: '',
      args: [],
    );
  }

  /// `Cancelled`
  String get cancelled {
    return Intl.message(
      'Cancelled',
      name: 'cancelled',
      desc: '',
      args: [],
    );
  }

  /// `Connect timeout`
  String get connectTimeout {
    return Intl.message(
      'Connect timeout',
      name: 'connectTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Receive timeout`
  String get receiveTimeout {
    return Intl.message(
      'Receive timeout',
      name: 'receiveTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Send timeout`
  String get sendTimeout {
    return Intl.message(
      'Send timeout',
      name: 'sendTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Please check internet connection`
  String get pleaseCheckInternetConnection {
    return Intl.message(
      'Please check internet connection',
      name: 'pleaseCheckInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Server error.`
  String get serverError {
    return Intl.message(
      'Server error.',
      name: 'serverError',
      desc: '',
      args: [],
    );
  }

  /// `Unknown error`
  String get unknownError {
    return Intl.message(
      'Unknown error',
      name: 'unknownError',
      desc: '',
      args: [],
    );
  }

  /// `Server unknown error`
  String get serverUnknownError {
    return Intl.message(
      'Server unknown error',
      name: 'serverUnknownError',
      desc: '',
      args: [],
    );
  }

  /// `Server not found`
  String get serverNotFound {
    return Intl.message(
      'Server not found',
      name: 'serverNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Database exception`
  String get databaseException {
    return Intl.message(
      'Database exception',
      name: 'databaseException',
      desc: '',
      args: [],
    );
  }

  /// `Back`
  String get back {
    return Intl.message(
      'Back',
      name: 'back',
      desc: '',
      args: [],
    );
  }

  /// `Welcome back!`
  String get welComeBack {
    return Intl.message(
      'Welcome back!',
      name: 'welComeBack',
      desc: '',
      args: [],
    );
  }

  /// `Login to continue.`
  String get loginToContinue {
    return Intl.message(
      'Login to continue.',
      name: 'loginToContinue',
      desc: '',
      args: [],
    );
  }

  /// `Email Address`
  String get emailAddress {
    return Intl.message(
      'Email Address',
      name: 'emailAddress',
      desc: '',
      args: [],
    );
  }

  /// `Password`
  String get password {
    return Intl.message(
      'Password',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  /// `Forgot Password?`
  String get forgotPassword {
    return Intl.message(
      'Forgot Password?',
      name: 'forgotPassword',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  /// `Confirm`
  String get kConfirm {
    return Intl.message(
      'Confirm',
      name: 'kConfirm',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure \n\nYou want to logout?`
  String get kLogoutMsg {
    return Intl.message(
      'Are you sure \n\nYou want to logout?',
      name: 'kLogoutMsg',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure \n\nYou want to delete account?`
  String get kDeleteAccount {
    return Intl.message(
      'Are you sure \n\nYou want to delete account?',
      name: 'kDeleteAccount',
      desc: '',
      args: [],
    );
  }

  /// `Please enter email address or mobile number`
  String get kEmptyField {
    return Intl.message(
      'Please enter email address or mobile number',
      name: 'kEmptyField',
      desc: '',
      args: [],
    );
  }

  /// `Please enter country code`
  String get kEnterCountryCode {
    return Intl.message(
      'Please enter country code',
      name: 'kEnterCountryCode',
      desc: '',
      args: [],
    );
  }

  /// `Please enter mobile number`
  String get kEnterMobileNumber {
    return Intl.message(
      'Please enter mobile number',
      name: 'kEnterMobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid mobile number`
  String get kEnterValidMobileNumber {
    return Intl.message(
      'Please enter valid mobile number',
      name: 'kEnterValidMobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid email address`
  String get kEnterValidEmailAddress {
    return Intl.message(
      'Please enter valid email address',
      name: 'kEnterValidEmailAddress',
      desc: '',
      args: [],
    );
  }

  /// `Please enter email address`
  String get kEnterEmailAddress {
    return Intl.message(
      'Please enter email address',
      name: 'kEnterEmailAddress',
      desc: '',
      args: [],
    );
  }

  /// `Please enter first name`
  String get kEnterFirstName {
    return Intl.message(
      'Please enter first name',
      name: 'kEnterFirstName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter at least 1 character for first name`
  String get kEnterValidFirstName {
    return Intl.message(
      'Please enter at least 1 character for first name',
      name: 'kEnterValidFirstName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter last name`
  String get kEnterLastName {
    return Intl.message(
      'Please enter last name',
      name: 'kEnterLastName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter at least 3 characters for last name`
  String get kEnterValidLastName {
    return Intl.message(
      'Please enter at least 3 characters for last name',
      name: 'kEnterValidLastName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter password`
  String get kEnterPassword {
    return Intl.message(
      'Please enter password',
      name: 'kEnterPassword',
      desc: '',
      args: [],
    );
  }

  /// `Password should be 8 or more characters`
  String get kEnterValidPassword {
    return Intl.message(
      'Password should be 8 or more characters',
      name: 'kEnterValidPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please enter new password`
  String get kEnterNewPassword {
    return Intl.message(
      'Please enter new password',
      name: 'kEnterNewPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please enter OTP`
  String get kPleaseEnterOtp {
    return Intl.message(
      'Please enter OTP',
      name: 'kPleaseEnterOtp',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid OTP`
  String get kPleaseEnterValidOtp {
    return Intl.message(
      'Please enter valid OTP',
      name: 'kPleaseEnterValidOtp',
      desc: '',
      args: [],
    );
  }

  /// `Ok`
  String get ok {
    return Intl.message(
      'Ok',
      name: 'ok',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  /// `Yes`
  String get yes {
    return Intl.message(
      'Yes',
      name: 'yes',
      desc: '',
      args: [],
    );
  }

  /// `No`
  String get no {
    return Intl.message(
      'No',
      name: 'no',
      desc: '',
      args: [],
    );
  }

  /// `Data not found`
  String get dataNotFound {
    return Intl.message(
      'Data not found',
      name: 'dataNotFound',
      desc: '',
      args: [],
    );
  }

  /// `Gallery`
  String get gallery {
    return Intl.message(
      'Gallery',
      name: 'gallery',
      desc: '',
      args: [],
    );
  }

  /// `Camera`
  String get camera {
    return Intl.message(
      'Camera',
      name: 'camera',
      desc: '',
      args: [],
    );
  }

  /// `Logout`
  String get logout {
    return Intl.message(
      'Logout',
      name: 'logout',
      desc: '',
      args: [],
    );
  }

  /// `Pick Image`
  String get pickImage {
    return Intl.message(
      'Pick Image',
      name: 'pickImage',
      desc: '',
      args: [],
    );
  }

  /// `Pick Video`
  String get pickVideo {
    return Intl.message(
      'Pick Video',
      name: 'pickVideo',
      desc: '',
      args: [],
    );
  }

  /// `Pick Documents`
  String get pickDocuments {
    return Intl.message(
      'Pick Documents',
      name: 'pickDocuments',
      desc: '',
      args: [],
    );
  }

  /// `Pick Audio`
  String get pickAudio {
    return Intl.message(
      'Pick Audio',
      name: 'pickAudio',
      desc: '',
      args: [],
    );
  }

  /// `Add New Card`
  String get addNewCard {
    return Intl.message(
      'Add New Card',
      name: 'addNewCard',
      desc: '',
      args: [],
    );
  }

  /// `Please enter your card details`
  String get addNewCardDesc {
    return Intl.message(
      'Please enter your card details',
      name: 'addNewCardDesc',
      desc: '',
      args: [],
    );
  }

  /// `Please enter card number`
  String get enterCardNumber {
    return Intl.message(
      'Please enter card number',
      name: 'enterCardNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter card name`
  String get enterCardName {
    return Intl.message(
      'Please enter card name',
      name: 'enterCardName',
      desc: '',
      args: [],
    );
  }

  /// `Please enter expiry date`
  String get enterExpiryDate {
    return Intl.message(
      'Please enter expiry date',
      name: 'enterExpiryDate',
      desc: '',
      args: [],
    );
  }

  /// `Please enter cvv`
  String get enterCvv {
    return Intl.message(
      'Please enter cvv',
      name: 'enterCvv',
      desc: '',
      args: [],
    );
  }

  /// `Card is invalid`
  String get numberIsInvalid {
    return Intl.message(
      'Card is invalid',
      name: 'numberIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Card Number`
  String get cardNumber {
    return Intl.message(
      'Card Number',
      name: 'cardNumber',
      desc: '',
      args: [],
    );
  }

  /// `Card Name`
  String get cardName {
    return Intl.message(
      'Card Name',
      name: 'cardName',
      desc: '',
      args: [],
    );
  }

  /// `Expiry Date`
  String get expiryDate {
    return Intl.message(
      'Expiry Date',
      name: 'expiryDate',
      desc: '',
      args: [],
    );
  }

  /// `Cvv`
  String get cvv {
    return Intl.message(
      'Cvv',
      name: 'cvv',
      desc: '',
      args: [],
    );
  }

  /// `Skip`
  String get skip {
    return Intl.message(
      'Skip',
      name: 'skip',
      desc: '',
      args: [],
    );
  }

  /// `Get Started`
  String get getStarted {
    return Intl.message(
      'Get Started',
      name: 'getStarted',
      desc: '',
      args: [],
    );
  }

  /// `Sign In With`
  String get signInWith {
    return Intl.message(
      'Sign In With',
      name: 'signInWith',
      desc: '',
      args: [],
    );
  }

  /// `Welcome Back!`
  String get welcomeBack {
    return Intl.message(
      'Welcome Back!',
      name: 'welcomeBack',
      desc: '',
      args: [],
    );
  }

  /// `Hello!`
  String get hello {
    return Intl.message(
      'Hello!',
      name: 'hello',
      desc: '',
      args: [],
    );
  }

  /// `Or`
  String get or {
    return Intl.message(
      'Or',
      name: 'or',
      desc: '',
      args: [],
    );
  }

  /// `Email`
  String get email {
    return Intl.message(
      'Email',
      name: 'email',
      desc: '',
      args: [],
    );
  }

  /// `Log in`
  String get logIn {
    return Intl.message(
      'Log in',
      name: 'logIn',
      desc: '',
      args: [],
    );
  }

  /// `Forgot?`
  String get forgot {
    return Intl.message(
      'Forgot?',
      name: 'forgot',
      desc: '',
      args: [],
    );
  }

  /// `Don"t have an account?`
  String get dontHaveAccount {
    return Intl.message(
      'Don"t have an account?',
      name: 'dontHaveAccount',
      desc: '',
      args: [],
    );
  }

  /// `Sign up`
  String get signUp {
    return Intl.message(
      'Sign up',
      name: 'signUp',
      desc: '',
      args: [],
    );
  }

  /// `Already have an account?`
  String get alreadyHaveAccount {
    return Intl.message(
      'Already have an account?',
      name: 'alreadyHaveAccount',
      desc: '',
      args: [],
    );
  }

  /// `Fill your below detail to create account`
  String get fillDetails {
    return Intl.message(
      'Fill your below detail to create account',
      name: 'fillDetails',
      desc: '',
      args: [],
    );
  }

  /// `Name`
  String get name {
    return Intl.message(
      'Name',
      name: 'name',
      desc: '',
      args: [],
    );
  }

  /// `Mobile Number`
  String get mobNumber {
    return Intl.message(
      'Mobile Number',
      name: 'mobNumber',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Password`
  String get confPassword {
    return Intl.message(
      'Confirm Password',
      name: 'confPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please enter confirm password`
  String get kConfPassword {
    return Intl.message(
      'Please enter confirm password',
      name: 'kConfPassword',
      desc: '',
      args: [],
    );
  }

  /// `I agree to `
  String get iAgree {
    return Intl.message(
      'I agree to ',
      name: 'iAgree',
      desc: '',
      args: [],
    );
  }

  /// `Terms & Conditions`
  String get tNc {
    return Intl.message(
      'Terms & Conditions',
      name: 'tNc',
      desc: '',
      args: [],
    );
  }

  /// ` and `
  String get and {
    return Intl.message(
      ' and ',
      name: 'and',
      desc: '',
      args: [],
    );
  }

  /// `Privacy Policy.`
  String get privacyPolicy {
    return Intl.message(
      'Privacy Policy.',
      name: 'privacyPolicy',
      desc: '',
      args: [],
    );
  }

  /// `Password and Confirm password not match`
  String get passwordMismatch {
    return Intl.message(
      'Password and Confirm password not match',
      name: 'passwordMismatch',
      desc: '',
      args: [],
    );
  }

  /// `Please accept $tNc $and $privacyPolicy`
  String get acceptTnC {
    return Intl.message(
      'Please accept \$tNc \$and \$privacyPolicy',
      name: 'acceptTnC',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  /// `Dashboard`
  String get dashboard {
    return Intl.message(
      'Dashboard',
      name: 'dashboard',
      desc: '',
      args: [],
    );
  }

  /// `Picked file count: `
  String get pickedFileCount {
    return Intl.message(
      'Picked file count: ',
      name: 'pickedFileCount',
      desc: '',
      args: [],
    );
  }

  /// `Photo Permission`
  String get photoPermission {
    return Intl.message(
      'Photo Permission',
      name: 'photoPermission',
      desc: '',
      args: [],
    );
  }

  /// `Permission denied always user need to allow manually`
  String get permissionDeniedAlwaysUserNeedToAllowManually {
    return Intl.message(
      'Permission denied always user need to allow manually',
      name: 'permissionDeniedAlwaysUserNeedToAllowManually',
      desc: '',
      args: [],
    );
  }

  /// `User Allowed to access photos`
  String get userAllowedToAccessPhotos {
    return Intl.message(
      'User Allowed to access photos',
      name: 'userAllowedToAccessPhotos',
      desc: '',
      args: [],
    );
  }

  /// `User Denied to access photos`
  String get userDeniedToAccessPhotos {
    return Intl.message(
      'User Denied to access photos',
      name: 'userDeniedToAccessPhotos',
      desc: '',
      args: [],
    );
  }

  /// `Search...`
  String get search {
    return Intl.message(
      'Search...',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  /// `Select your phone code`
  String get selectYourPhoneCode {
    return Intl.message(
      'Select your phone code',
      name: 'selectYourPhoneCode',
      desc: '',
      args: [],
    );
  }

  /// `Error During Communication:`
  String get errorDuringCommunication {
    return Intl.message(
      'Error During Communication:',
      name: 'errorDuringCommunication',
      desc: '',
      args: [],
    );
  }

  /// `Invalid Request:`
  String get invalidRequest {
    return Intl.message(
      'Invalid Request:',
      name: 'invalidRequest',
      desc: '',
      args: [],
    );
  }

  /// `Unauthorised:`
  String get unauthorised {
    return Intl.message(
      'Unauthorised:',
      name: 'unauthorised',
      desc: '',
      args: [],
    );
  }

  /// `Invalid Input:`
  String get invalidInput {
    return Intl.message(
      'Invalid Input:',
      name: 'invalidInput',
      desc: '',
      args: [],
    );
  }

  /// `No Active Internet Connection`
  String get noActiveInternetConnection {
    return Intl.message(
      'No Active Internet Connection',
      name: 'noActiveInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Connection to server failed due to internet connection.`
  String get connectionToServerFailedDueToInternetConnection {
    return Intl.message(
      'Connection to server failed due to internet connection.',
      name: 'connectionToServerFailedDueToInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Something went wrong. Please try after sometime.`
  String get somethingWentWrongPleaseTryAfterSometime {
    return Intl.message(
      'Something went wrong. Please try after sometime.',
      name: 'somethingWentWrongPleaseTryAfterSometime',
      desc: '',
      args: [],
    );
  }

  /// `Request to server was cancelled`
  String get requestToServerWasCancelled {
    return Intl.message(
      'Request to server was cancelled',
      name: 'requestToServerWasCancelled',
      desc: '',
      args: [],
    );
  }

  /// `Connection timeout with server`
  String get connectionTimeoutWithServer {
    return Intl.message(
      'Connection timeout with server',
      name: 'connectionTimeoutWithServer',
      desc: '',
      args: [],
    );
  }

  /// `Request can't be handled for now. Please try after sometime.`
  String get requestCantBeHandledForNowPleaseTryAfterSometime {
    return Intl.message(
      'Request can\'t be handled for now. Please try after sometime.',
      name: 'requestCantBeHandledForNowPleaseTryAfterSometime',
      desc: '',
      args: [],
    );
  }

  /// `Please login again.`
  String get pleaseLoginAgain {
    return Intl.message(
      'Please login again.',
      name: 'pleaseLoginAgain',
      desc: '',
      args: [],
    );
  }

  /// `Something when wrong. Please try again.`
  String get somethingWhenWrongPleaseTryAgain {
    return Intl.message(
      'Something when wrong. Please try again.',
      name: 'somethingWhenWrongPleaseTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `Error uploading photo`
  String get errorUploadingPhoto {
    return Intl.message(
      'Error uploading photo',
      name: 'errorUploadingPhoto',
      desc: '',
      args: [],
    );
  }

  /// `CVV is invalid`
  String get cvvIsInvalid {
    return Intl.message(
      'CVV is invalid',
      name: 'cvvIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Expiry month is invalid`
  String get expiryMonthIsInvalid {
    return Intl.message(
      'Expiry month is invalid',
      name: 'expiryMonthIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Expiry year is invalid`
  String get expiryYearIsInvalid {
    return Intl.message(
      'Expiry year is invalid',
      name: 'expiryYearIsInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Card has expired`
  String get cardHasExpired {
    return Intl.message(
      'Card has expired',
      name: 'cardHasExpired',
      desc: '',
      args: [],
    );
  }

  /// `Please check your internet connection`
  String get pleaseCheckYourInternetConnection {
    return Intl.message(
      'Please check your internet connection',
      name: 'pleaseCheckYourInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Add employee`
  String get addEmployee {
    return Intl.message(
      'Add employee',
      name: 'addEmployee',
      desc: '',
      args: [],
    );
  }

  /// `Trendy Collection`
  String get trendyCollection {
    return Intl.message(
      'Trendy Collection',
      name: 'trendyCollection',
      desc: '',
      args: [],
    );
  }

  /// `Let’s Create your own`
  String get letsCreateYourOwn {
    return Intl.message(
      'Let’s Create your own',
      name: 'letsCreateYourOwn',
      desc: '',
      args: [],
    );
  }

  /// `style`
  String get style {
    return Intl.message(
      'style',
      name: 'style',
      desc: '',
      args: [],
    );
  }

  /// `Continue as a guest`
  String get continueAsAGuest {
    return Intl.message(
      'Continue as a guest',
      name: 'continueAsAGuest',
      desc: '',
      args: [],
    );
  }

  /// `Sign In`
  String get signIn {
    return Intl.message(
      'Sign In',
      name: 'signIn',
      desc: '',
      args: [],
    );
  }

  /// `Payments`
  String get payments {
    return Intl.message(
      'Payments',
      name: 'payments',
      desc: '',
      args: [],
    );
  }

  /// `100% secure`
  String get Secure {
    return Intl.message(
      '100% secure',
      name: 'Secure',
      desc: '',
      args: [],
    );
  }

  /// `payment`
  String get payment {
    return Intl.message(
      'payment',
      name: 'payment',
      desc: '',
      args: [],
    );
  }

  /// `Track Order`
  String get trackOrder {
    return Intl.message(
      'Track Order',
      name: 'trackOrder',
      desc: '',
      args: [],
    );
  }

  /// `Experience the realtime`
  String get experienceTheRealtime {
    return Intl.message(
      'Experience the realtime',
      name: 'experienceTheRealtime',
      desc: '',
      args: [],
    );
  }

  /// `Tracking`
  String get tracking {
    return Intl.message(
      'Tracking',
      name: 'tracking',
      desc: '',
      args: [],
    );
  }

  /// `SIgn In to`
  String get signInTo {
    return Intl.message(
      'SIgn In to',
      name: 'signInTo',
      desc: '',
      args: [],
    );
  }

  /// `BagZag`
  String get bagzag {
    return Intl.message(
      'BagZag',
      name: 'bagzag',
      desc: '',
      args: [],
    );
  }

  /// `Please enter email / phone number`
  String get pleaseEnterEmailPhoneNumber {
    return Intl.message(
      'Please enter email / phone number',
      name: 'pleaseEnterEmailPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Email / Phone Number`
  String get emailPhoneNumber {
    return Intl.message(
      'Email / Phone Number',
      name: 'emailPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `LoggedIn succesfully`
  String get loggedinSuccesfully {
    return Intl.message(
      'LoggedIn succesfully',
      name: 'loggedinSuccesfully',
      desc: '',
      args: [],
    );
  }

  /// `Enter your email address or mobile number we'll send you a link to reset password.`
  String get enterYourEmailAddressOrMobileNumberWellSendYou {
    return Intl.message(
      'Enter your email address or mobile number we\'ll send you a link to reset password.',
      name: 'enterYourEmailAddressOrMobileNumberWellSendYou',
      desc: '',
      args: [],
    );
  }

  /// `Mobile`
  String get mobile {
    return Intl.message(
      'Mobile',
      name: 'mobile',
      desc: '',
      args: [],
    );
  }

  /// `Submit`
  String get submit {
    return Intl.message(
      'Submit',
      name: 'submit',
      desc: '',
      args: [],
    );
  }

  /// `Check Your Email`
  String get checkYourEmail {
    return Intl.message(
      'Check Your Email',
      name: 'checkYourEmail',
      desc: '',
      args: [],
    );
  }

  /// `We have sent instructions on how to reset the password.`
  String get weHaveSentInstructionsOnHowToResetThePassword {
    return Intl.message(
      'We have sent instructions on how to reset the password.',
      name: 'weHaveSentInstructionsOnHowToResetThePassword',
      desc: '',
      args: [],
    );
  }

  /// `Mobile Number`
  String get mobileNumber {
    return Intl.message(
      'Mobile Number',
      name: 'mobileNumber',
      desc: '',
      args: [],
    );
  }

  /// `Choose your country code`
  String get chooseYourCountryCode {
    return Intl.message(
      'Choose your country code',
      name: 'chooseYourCountryCode',
      desc: '',
      args: [],
    );
  }

  /// `Get OTP`
  String get getOtp {
    return Intl.message(
      'Get OTP',
      name: 'getOtp',
      desc: '',
      args: [],
    );
  }

  /// `Phone Verification`
  String get phoneVerification {
    return Intl.message(
      'Phone Verification',
      name: 'phoneVerification',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the verification code, we sent to your Mobile Number`
  String get pleaseEnterTheVerificationCodeWeSentToYourMobile {
    return Intl.message(
      'Please enter the verification code, we sent to your Mobile Number',
      name: 'pleaseEnterTheVerificationCodeWeSentToYourMobile',
      desc: '',
      args: [],
    );
  }

  /// `Please enter otp`
  String get pleaseEnterOtp {
    return Intl.message(
      'Please enter otp',
      name: 'pleaseEnterOtp',
      desc: '',
      args: [],
    );
  }

  /// `Please enter 4 digit otp`
  String get pleaseEnter4DigitOtp {
    return Intl.message(
      'Please enter 4 digit otp',
      name: 'pleaseEnter4DigitOtp',
      desc: '',
      args: [],
    );
  }

  /// `Verify`
  String get verify {
    return Intl.message(
      'Verify',
      name: 'verify',
      desc: '',
      args: [],
    );
  }

  /// `Reset Password`
  String get resetPassword {
    return Intl.message(
      'Reset Password',
      name: 'resetPassword',
      desc: '',
      args: [],
    );
  }

  /// `Enter new password below.`
  String get enterNewPasswordBelow {
    return Intl.message(
      'Enter new password below.',
      name: 'enterNewPasswordBelow',
      desc: '',
      args: [],
    );
  }

  /// `Resend Code`
  String get resendCode {
    return Intl.message(
      'Resend Code',
      name: 'resendCode',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Password`
  String get confirmPassword {
    return Intl.message(
      'Confirm Password',
      name: 'confirmPassword',
      desc: '',
      args: [],
    );
  }

  /// `Update`
  String get update {
    return Intl.message(
      'Update',
      name: 'update',
      desc: '',
      args: [],
    );
  }

  /// `Password updated succesfully`
  String get passwordUpdatedSuccesfully {
    return Intl.message(
      'Password updated succesfully',
      name: 'passwordUpdatedSuccesfully',
      desc: '',
      args: [],
    );
  }

  /// `Please enter confirm password`
  String get pleaseEnterConfirmPassword {
    return Intl.message(
      'Please enter confirm password',
      name: 'pleaseEnterConfirmPassword',
      desc: '',
      args: [],
    );
  }

  /// `Password & confirm password must be same`
  String get passwordConfirmPasswordMustBeSame {
    return Intl.message(
      'Password & confirm password must be same',
      name: 'passwordConfirmPasswordMustBeSame',
      desc: '',
      args: [],
    );
  }

  /// `First Name`
  String get firstName {
    return Intl.message(
      'First Name',
      name: 'firstName',
      desc: '',
      args: [],
    );
  }

  /// `Last Name`
  String get lastName {
    return Intl.message(
      'Last Name',
      name: 'lastName',
      desc: '',
      args: [],
    );
  }

  /// `New Password`
  String get newPassword {
    return Intl.message(
      'New Password',
      name: 'newPassword',
      desc: '',
      args: [],
    );
  }

  /// `I agree to`
  String get iAgreeTo {
    return Intl.message(
      'I agree to',
      name: 'iAgreeTo',
      desc: '',
      args: [],
    );
  }

  /// `Terms & Condition`
  String get termsCondition {
    return Intl.message(
      'Terms & Condition',
      name: 'termsCondition',
      desc: '',
      args: [],
    );
  }

  /// `Please accept terms & conditions`
  String get pleaseAcceptTermsConditions {
    return Intl.message(
      'Please accept terms & conditions',
      name: 'pleaseAcceptTermsConditions',
      desc: '',
      args: [],
    );
  }

  /// `Hi,`
  String get hi {
    return Intl.message(
      'Hi,',
      name: 'hi',
      desc: '',
      args: [],
    );
  }

  /// `Bestseller Product`
  String get bestsellerProduct {
    return Intl.message(
      'Bestseller Product',
      name: 'bestsellerProduct',
      desc: '',
      args: [],
    );
  }

  /// `View More`
  String get viewMore {
    return Intl.message(
      'View More',
      name: 'viewMore',
      desc: '',
      args: [],
    );
  }

  /// `Categories`
  String get categories {
    return Intl.message(
      'Categories',
      name: 'categories',
      desc: '',
      args: [],
    );
  }

  /// `Free Shipping`
  String get freeShipping {
    return Intl.message(
      'Free Shipping',
      name: 'freeShipping',
      desc: '',
      args: [],
    );
  }

  /// `New Collection from BagZag.`
  String get newCollectionFromBagzag {
    return Intl.message(
      'New Collection from BagZag.',
      name: 'newCollectionFromBagzag',
      desc: '',
      args: [],
    );
  }

  /// `David`
  String get david {
    return Intl.message(
      'David',
      name: 'david',
      desc: '',
      args: [],
    );
  }

  /// `Recently viewed By You`
  String get recentlyViewedByYou {
    return Intl.message(
      'Recently viewed By You',
      name: 'recentlyViewedByYou',
      desc: '',
      args: [],
    );
  }

  /// `Loose Textured T-Shirt`
  String get looseTexturedTshirt {
    return Intl.message(
      'Loose Textured T-Shirt',
      name: 'looseTexturedTshirt',
      desc: '',
      args: [],
    );
  }

  /// `Bestseller`
  String get bestseller {
    return Intl.message(
      'Bestseller',
      name: 'bestseller',
      desc: '',
      args: [],
    );
  }

  /// `Buyer’s Most Loved`
  String get buyersMostLoved {
    return Intl.message(
      'Buyer’s Most Loved',
      name: 'buyersMostLoved',
      desc: '',
      args: [],
    );
  }

  /// `Find Things You’ll Love`
  String get findThingsYoullLove {
    return Intl.message(
      'Find Things You’ll Love',
      name: 'findThingsYoullLove',
      desc: '',
      args: [],
    );
  }

  /// `Enter a valid email or phone number`
  String get enterAValidEmailOrPhoneNumber {
    return Intl.message(
      'Enter a valid email or phone number',
      name: 'enterAValidEmailOrPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Studio`
  String get studio {
    return Intl.message(
      'Studio',
      name: 'studio',
      desc: '',
      args: [],
    );
  }

  /// `Sell`
  String get sell {
    return Intl.message(
      'Sell',
      name: 'sell',
      desc: '',
      args: [],
    );
  }

  /// `Feed`
  String get feed {
    return Intl.message(
      'Feed',
      name: 'feed',
      desc: '',
      args: [],
    );
  }

  /// `Me`
  String get me {
    return Intl.message(
      'Me',
      name: 'me',
      desc: '',
      args: [],
    );
  }

  /// `Recent Searches`
  String get recentSearches {
    return Intl.message(
      'Recent Searches',
      name: 'recentSearches',
      desc: '',
      args: [],
    );
  }

  /// `No products found!!`
  String get noProductsFound {
    return Intl.message(
      'No products found!!',
      name: 'noProductsFound',
      desc: '',
      args: [],
    );
  }

  /// `Store`
  String get store {
    return Intl.message(
      'Store',
      name: 'store',
      desc: '',
      args: [],
    );
  }

  /// `Products`
  String get products {
    return Intl.message(
      'Products',
      name: 'products',
      desc: '',
      args: [],
    );
  }

  /// `Favorites`
  String get favorites {
    return Intl.message(
      'Favorites',
      name: 'favorites',
      desc: '',
      args: [],
    );
  }

  /// `The New Store`
  String get theNewStore {
    return Intl.message(
      'The New Store',
      name: 'theNewStore',
      desc: '',
      args: [],
    );
  }

  /// `3038 Godfrey Street Tigard, OR 97223`
  String get GodfreyStreetTigardOr97223 {
    return Intl.message(
      '3038 Godfrey Street Tigard, OR 97223',
      name: 'GodfreyStreetTigardOr97223',
      desc: '',
      args: [],
    );
  }

  /// `Seven Sennse Store`
  String get sevenSennseStore {
    return Intl.message(
      'Seven Sennse Store',
      name: 'sevenSennseStore',
      desc: '',
      args: [],
    );
  }

  /// `Men`
  String get men {
    return Intl.message(
      'Men',
      name: 'men',
      desc: '',
      args: [],
    );
  }

  /// `Women`
  String get women {
    return Intl.message(
      'Women',
      name: 'women',
      desc: '',
      args: [],
    );
  }

  /// `Kids`
  String get kids {
    return Intl.message(
      'Kids',
      name: 'kids',
      desc: '',
      args: [],
    );
  }

  /// `Beauty`
  String get beauty {
    return Intl.message(
      'Beauty',
      name: 'beauty',
      desc: '',
      args: [],
    );
  }

  /// `Home & Living`
  String get homeLiving {
    return Intl.message(
      'Home & Living',
      name: 'homeLiving',
      desc: '',
      args: [],
    );
  }

  /// `Gedgets`
  String get gedgets {
    return Intl.message(
      'Gedgets',
      name: 'gedgets',
      desc: '',
      args: [],
    );
  }

  /// `Toy & Baby`
  String get toyBaby {
    return Intl.message(
      'Toy & Baby',
      name: 'toyBaby',
      desc: '',
      args: [],
    );
  }

  /// `Sports`
  String get sports {
    return Intl.message(
      'Sports',
      name: 'sports',
      desc: '',
      args: [],
    );
  }

  /// `Browse Categories`
  String get browseCategories {
    return Intl.message(
      'Browse Categories',
      name: 'browseCategories',
      desc: '',
      args: [],
    );
  }

  /// `Follow`
  String get follow {
    return Intl.message(
      'Follow',
      name: 'follow',
      desc: '',
      args: [],
    );
  }

  /// `Shop Products`
  String get shopProducts {
    return Intl.message(
      'Shop Products',
      name: 'shopProducts',
      desc: '',
      args: [],
    );
  }

  /// `Followed`
  String get followed {
    return Intl.message(
      'Followed',
      name: 'followed',
      desc: '',
      args: [],
    );
  }

  /// `Following`
  String get following {
    return Intl.message(
      'Following',
      name: 'following',
      desc: '',
      args: [],
    );
  }

  /// `Recommended Products`
  String get recommendedProducts {
    return Intl.message(
      'Recommended Products',
      name: 'recommendedProducts',
      desc: '',
      args: [],
    );
  }

  /// `My Order`
  String get myOrder {
    return Intl.message(
      'My Order',
      name: 'myOrder',
      desc: '',
      args: [],
    );
  }

  /// `You can see all pending and past orders.`
  String get youCanSeeAllPendingAndPastOrders {
    return Intl.message(
      'You can see all pending and past orders.',
      name: 'youCanSeeAllPendingAndPastOrders',
      desc: '',
      args: [],
    );
  }

  /// `The Libas`
  String get theLibas {
    return Intl.message(
      'The Libas',
      name: 'theLibas',
      desc: '',
      args: [],
    );
  }

  /// `Mocha Shoes`
  String get mochaShoes {
    return Intl.message(
      'Mocha Shoes',
      name: 'mochaShoes',
      desc: '',
      args: [],
    );
  }

  /// `The New Shop`
  String get theNewShop {
    return Intl.message(
      'The New Shop',
      name: 'theNewShop',
      desc: '',
      args: [],
    );
  }

  /// `Happy Shop`
  String get happyShop {
    return Intl.message(
      'Happy Shop',
      name: 'happyShop',
      desc: '',
      args: [],
    );
  }

  /// `Boyish`
  String get boyish {
    return Intl.message(
      'Boyish',
      name: 'boyish',
      desc: '',
      args: [],
    );
  }

  /// `Bookmarks`
  String get bookmarks {
    return Intl.message(
      'Bookmarks',
      name: 'bookmarks',
      desc: '',
      args: [],
    );
  }

  /// `You can see all bookmark post.`
  String get youCanSeeAllBookmarkPost {
    return Intl.message(
      'You can see all bookmark post.',
      name: 'youCanSeeAllBookmarkPost',
      desc: '',
      args: [],
    );
  }

  /// `You can see branded store.`
  String get youCanSeeBrandedStore {
    return Intl.message(
      'You can see branded store.',
      name: 'youCanSeeBrandedStore',
      desc: '',
      args: [],
    );
  }

  /// `BagZag Mall`
  String get bagzagMall {
    return Intl.message(
      'BagZag Mall',
      name: 'bagzagMall',
      desc: '',
      args: [],
    );
  }

  /// `Find People`
  String get findPeople {
    return Intl.message(
      'Find People',
      name: 'findPeople',
      desc: '',
      args: [],
    );
  }

  /// `You can search people who are using the app`
  String get youCanSearchPeopleWhoAreUsingTheApp {
    return Intl.message(
      'You can search people who are using the app',
      name: 'youCanSearchPeopleWhoAreUsingTheApp',
      desc: '',
      args: [],
    );
  }

  /// `My Post`
  String get myPost {
    return Intl.message(
      'My Post',
      name: 'myPost',
      desc: '',
      args: [],
    );
  }

  /// `See all product post created by you.`
  String get seeAllProductPostCreatedByYou {
    return Intl.message(
      'See all product post created by you.',
      name: 'seeAllProductPostCreatedByYou',
      desc: '',
      args: [],
    );
  }

  /// `Gift Card`
  String get giftCard {
    return Intl.message(
      'Gift Card',
      name: 'giftCard',
      desc: '',
      args: [],
    );
  }

  /// `You can send gift to other`
  String get youCanSendGiftToOther {
    return Intl.message(
      'You can send gift to other',
      name: 'youCanSendGiftToOther',
      desc: '',
      args: [],
    );
  }

  /// `Messages`
  String get messages {
    return Intl.message(
      'Messages',
      name: 'messages',
      desc: '',
      args: [],
    );
  }

  /// `You can see list of your messages`
  String get youCanSeeListOfYourMessages {
    return Intl.message(
      'You can see list of your messages',
      name: 'youCanSeeListOfYourMessages',
      desc: '',
      args: [],
    );
  }

  /// `You can add/remove payment methods.`
  String get youCanAddremovePaymentMethods {
    return Intl.message(
      'You can add/remove payment methods.',
      name: 'youCanAddremovePaymentMethods',
      desc: '',
      args: [],
    );
  }

  /// `Payment Methods`
  String get paymentMethods {
    return Intl.message(
      'Payment Methods',
      name: 'paymentMethods',
      desc: '',
      args: [],
    );
  }

  /// `Manage Addresses`
  String get manageAddresses {
    return Intl.message(
      'Manage Addresses',
      name: 'manageAddresses',
      desc: '',
      args: [],
    );
  }

  /// `Manage billing & shipping addresses.`
  String get manageBillingShippingAddresses {
    return Intl.message(
      'Manage billing & shipping addresses.',
      name: 'manageBillingShippingAddresses',
      desc: '',
      args: [],
    );
  }

  /// `Invite & Earn`
  String get inviteEarn {
    return Intl.message(
      'Invite & Earn',
      name: 'inviteEarn',
      desc: '',
      args: [],
    );
  }

  /// `You can invite other user & earn money.`
  String get youCanInviteOtherUserEarnMoney {
    return Intl.message(
      'You can invite other user & earn money.',
      name: 'youCanInviteOtherUserEarnMoney',
      desc: '',
      args: [],
    );
  }

  /// `Settings`
  String get settings {
    return Intl.message(
      'Settings',
      name: 'settings',
      desc: '',
      args: [],
    );
  }

  /// `See all app settings`
  String get seeAllAppSettings {
    return Intl.message(
      'See all app settings',
      name: 'seeAllAppSettings',
      desc: '',
      args: [],
    );
  }

  /// `David Marco`
  String get davidMarco {
    return Intl.message(
      'David Marco',
      name: 'davidMarco',
      desc: '',
      args: [],
    );
  }

  /// `Edit`
  String get edit {
    return Intl.message(
      'Edit',
      name: 'edit',
      desc: '',
      args: [],
    );
  }

  /// `Account`
  String get account {
    return Intl.message(
      'Account',
      name: 'account',
      desc: '',
      args: [],
    );
  }

  /// `Followers`
  String get followers {
    return Intl.message(
      'Followers',
      name: 'followers',
      desc: '',
      args: [],
    );
  }

  /// `Shares`
  String get shares {
    return Intl.message(
      'Shares',
      name: 'shares',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid password`
  String get pleaseEnterValidPassword {
    return Intl.message(
      'Please enter valid password',
      name: 'pleaseEnterValidPassword',
      desc: '',
      args: [],
    );
  }

  /// `Please enter 8 characters password`
  String get pleaseEnter8CharactersPassword {
    return Intl.message(
      'Please enter 8 characters password',
      name: 'pleaseEnter8CharactersPassword',
      desc: '',
      args: [],
    );
  }

  /// `Notification(On/Off)`
  String get notificationonoff {
    return Intl.message(
      'Notification(On/Off)',
      name: 'notificationonoff',
      desc: '',
      args: [],
    );
  }

  /// `Sharing Settings`
  String get sharingSettings {
    return Intl.message(
      'Sharing Settings',
      name: 'sharingSettings',
      desc: '',
      args: [],
    );
  }

  /// `Clear History`
  String get clearHistory {
    return Intl.message(
      'Clear History',
      name: 'clearHistory',
      desc: '',
      args: [],
    );
  }

  /// `Close Account`
  String get closeAccount {
    return Intl.message(
      'Close Account',
      name: 'closeAccount',
      desc: '',
      args: [],
    );
  }

  /// `Change Password`
  String get changePassword {
    return Intl.message(
      'Change Password',
      name: 'changePassword',
      desc: '',
      args: [],
    );
  }

  /// `Rate App`
  String get rateApp {
    return Intl.message(
      'Rate App',
      name: 'rateApp',
      desc: '',
      args: [],
    );
  }

  /// `Share App`
  String get shareApp {
    return Intl.message(
      'Share App',
      name: 'shareApp',
      desc: '',
      args: [],
    );
  }

  /// `Help Center`
  String get helpCenter {
    return Intl.message(
      'Help Center',
      name: 'helpCenter',
      desc: '',
      args: [],
    );
  }

  /// `Terms of Use`
  String get termsOfUse {
    return Intl.message(
      'Terms of Use',
      name: 'termsOfUse',
      desc: '',
      args: [],
    );
  }

  /// `About Us`
  String get aboutUs {
    return Intl.message(
      'About Us',
      name: 'aboutUs',
      desc: '',
      args: [],
    );
  }

  /// `Contact Us`
  String get contactUs {
    return Intl.message(
      'Contact Us',
      name: 'contactUs',
      desc: '',
      args: [],
    );
  }

  /// `Notification On`
  String get notificationOn {
    return Intl.message(
      'Notification On',
      name: 'notificationOn',
      desc: '',
      args: [],
    );
  }

  /// `You can change the password for security purpose.`
  String get youCanChangeThePasswordForSecurityPurpose {
    return Intl.message(
      'You can change the password for security purpose.',
      name: 'youCanChangeThePasswordForSecurityPurpose',
      desc: '',
      args: [],
    );
  }

  /// `Password changed successfully`
  String get passwordChangedSuccessfully {
    return Intl.message(
      'Password changed successfully',
      name: 'passwordChangedSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `Subject`
  String get subject {
    return Intl.message(
      'Subject',
      name: 'subject',
      desc: '',
      args: [],
    );
  }

  /// `Description`
  String get description {
    return Intl.message(
      'Description',
      name: 'description',
      desc: '',
      args: [],
    );
  }

  /// `ThankYou!!`
  String get thankyou {
    return Intl.message(
      'ThankYou!!',
      name: 'thankyou',
      desc: '',
      args: [],
    );
  }

  /// `Please enter description`
  String get pleaseEnterDescription {
    return Intl.message(
      'Please enter description',
      name: 'pleaseEnterDescription',
      desc: '',
      args: [],
    );
  }

  /// `Please enter subject`
  String get pleaseEnterSubject {
    return Intl.message(
      'Please enter subject',
      name: 'pleaseEnterSubject',
      desc: '',
      args: [],
    );
  }

  /// `Connected`
  String get connected {
    return Intl.message(
      'Connected',
      name: 'connected',
      desc: '',
      args: [],
    );
  }

  /// `Connect`
  String get connect {
    return Intl.message(
      'Connect',
      name: 'connect',
      desc: '',
      args: [],
    );
  }

  /// `Michaele Lusiada`
  String get michaeleLusiada {
    return Intl.message(
      'Michaele Lusiada',
      name: 'michaeleLusiada',
      desc: '',
      args: [],
    );
  }

  /// `Followings`
  String get followings {
    return Intl.message(
      'Followings',
      name: 'followings',
      desc: '',
      args: [],
    );
  }

  /// `Post`
  String get post {
    return Intl.message(
      'Post',
      name: 'post',
      desc: '',
      args: [],
    );
  }

  /// `It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. \n`
  String get itIsALongEstablishedFactThatAReaderWill {
    return Intl.message(
      'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. \n',
      name: 'itIsALongEstablishedFactThatAReaderWill',
      desc: '',
      args: [],
    );
  }

  /// `See More`
  String get seeMore {
    return Intl.message(
      'See More',
      name: 'seeMore',
      desc: '',
      args: [],
    );
  }

  /// `See Less`
  String get seeLess {
    return Intl.message(
      'See Less',
      name: 'seeLess',
      desc: '',
      args: [],
    );
  }

  /// `Add Story`
  String get addStory {
    return Intl.message(
      'Add Story',
      name: 'addStory',
      desc: '',
      args: [],
    );
  }

  /// `Michael`
  String get michael {
    return Intl.message(
      'Michael',
      name: 'michael',
      desc: '',
      args: [],
    );
  }

  /// `Rubina`
  String get rubina {
    return Intl.message(
      'Rubina',
      name: 'rubina',
      desc: '',
      args: [],
    );
  }

  /// `Arzyan`
  String get arzyan {
    return Intl.message(
      'Arzyan',
      name: 'arzyan',
      desc: '',
      args: [],
    );
  }

  /// `Like New`
  String get likeNew {
    return Intl.message(
      'Like New',
      name: 'likeNew',
      desc: '',
      args: [],
    );
  }

  /// `Create Post`
  String get createPost {
    return Intl.message(
      'Create Post',
      name: 'createPost',
      desc: '',
      args: [],
    );
  }

  /// `Please enter product name`
  String get pleaseEnterProductName {
    return Intl.message(
      'Please enter product name',
      name: 'pleaseEnterProductName',
      desc: '',
      args: [],
    );
  }

  /// `Category`
  String get category {
    return Intl.message(
      'Category',
      name: 'category',
      desc: '',
      args: [],
    );
  }

  /// `Subcategory`
  String get subcategory {
    return Intl.message(
      'Subcategory',
      name: 'subcategory',
      desc: '',
      args: [],
    );
  }

  /// `Brand`
  String get brand {
    return Intl.message(
      'Brand',
      name: 'brand',
      desc: '',
      args: [],
    );
  }

  /// `Color`
  String get color {
    return Intl.message(
      'Color',
      name: 'color',
      desc: '',
      args: [],
    );
  }

  /// `Size`
  String get size {
    return Intl.message(
      'Size',
      name: 'size',
      desc: '',
      args: [],
    );
  }

  /// `Good`
  String get good {
    return Intl.message(
      'Good',
      name: 'good',
      desc: '',
      args: [],
    );
  }

  /// `Please enter selling price`
  String get pleaseEnterSellingPrice {
    return Intl.message(
      'Please enter selling price',
      name: 'pleaseEnterSellingPrice',
      desc: '',
      args: [],
    );
  }

  /// `Your post uploaded successfully`
  String get yourPostUploadedSuccessfully {
    return Intl.message(
      'Your post uploaded successfully',
      name: 'yourPostUploadedSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `Please enter category, subcategory, brand details`
  String get pleaseEnterCategorySubcategoryBrandDetails {
    return Intl.message(
      'Please enter category, subcategory, brand details',
      name: 'pleaseEnterCategorySubcategoryBrandDetails',
      desc: '',
      args: [],
    );
  }

  /// `Create Story`
  String get createStory {
    return Intl.message(
      'Create Story',
      name: 'createStory',
      desc: '',
      args: [],
    );
  }

  /// `Please enter caption title`
  String get pleaseEnterCaptionTitle {
    return Intl.message(
      'Please enter caption title',
      name: 'pleaseEnterCaptionTitle',
      desc: '',
      args: [],
    );
  }

  /// `Caption Title`
  String get captionTitle {
    return Intl.message(
      'Caption Title',
      name: 'captionTitle',
      desc: '',
      args: [],
    );
  }

  /// `Send message`
  String get sendMessage {
    return Intl.message(
      'Send message',
      name: 'sendMessage',
      desc: '',
      args: [],
    );
  }

  /// `Message sent successfully`
  String get messageSentSuccessfully {
    return Intl.message(
      'Message sent successfully',
      name: 'messageSentSuccessfully',
      desc: '',
      args: [],
    );
  }

  /// `Comments (30)`
  String get comments30 {
    return Intl.message(
      'Comments (30)',
      name: 'comments30',
      desc: '',
      args: [],
    );
  }

  /// `Lorem ipsum dolor sit amet, consecrate sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut`
  String get loremIpsumDolorSitAmetConsecrateSadipscingElitrSedDiam {
    return Intl.message(
      'Lorem ipsum dolor sit amet, consecrate sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut',
      name: 'loremIpsumDolorSitAmetConsecrateSadipscingElitrSedDiam',
      desc: '',
      args: [],
    );
  }

  /// `Fashion T shirt`
  String get fashionTShirt {
    return Intl.message(
      'Fashion T shirt',
      name: 'fashionTShirt',
      desc: '',
      args: [],
    );
  }

  /// `Fashion Tops`
  String get fashionTops {
    return Intl.message(
      'Fashion Tops',
      name: 'fashionTops',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
