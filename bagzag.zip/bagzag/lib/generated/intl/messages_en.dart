// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "GodfreyStreetTigardOr97223": MessageLookupByLibrary.simpleMessage(
            "3038 Godfrey Street Tigard, OR 97223"),
        "Secure": MessageLookupByLibrary.simpleMessage("100% secure"),
        "aboutUs": MessageLookupByLibrary.simpleMessage("About Us"),
        "acceptTnC": MessageLookupByLibrary.simpleMessage(
            "Please accept \$tNc \$and \$privacyPolicy"),
        "account": MessageLookupByLibrary.simpleMessage("Account"),
        "addEmployee": MessageLookupByLibrary.simpleMessage("Add employee"),
        "addNewCard": MessageLookupByLibrary.simpleMessage("Add New Card"),
        "addNewCardDesc": MessageLookupByLibrary.simpleMessage(
            "Please enter your card details"),
        "addStory": MessageLookupByLibrary.simpleMessage("Add Story"),
        "alreadyHaveAccount":
            MessageLookupByLibrary.simpleMessage("Already have an account?"),
        "and": MessageLookupByLibrary.simpleMessage(" and "),
        "applicationTitle":
            MessageLookupByLibrary.simpleMessage("Flutter Demo Structure"),
        "arzyan": MessageLookupByLibrary.simpleMessage("Arzyan"),
        "back": MessageLookupByLibrary.simpleMessage("Back"),
        "bagzag": MessageLookupByLibrary.simpleMessage("BagZag"),
        "bagzagMall": MessageLookupByLibrary.simpleMessage("BagZag Mall"),
        "beauty": MessageLookupByLibrary.simpleMessage("Beauty"),
        "bestseller": MessageLookupByLibrary.simpleMessage("Bestseller"),
        "bestsellerProduct":
            MessageLookupByLibrary.simpleMessage("Bestseller Product"),
        "bookmarks": MessageLookupByLibrary.simpleMessage("Bookmarks"),
        "boyish": MessageLookupByLibrary.simpleMessage("Boyish"),
        "brand": MessageLookupByLibrary.simpleMessage("Brand"),
        "browseCategories":
            MessageLookupByLibrary.simpleMessage("Browse Categories"),
        "buyersMostLoved":
            MessageLookupByLibrary.simpleMessage("Buyer’s Most Loved"),
        "camera": MessageLookupByLibrary.simpleMessage("Camera"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "cancelled": MessageLookupByLibrary.simpleMessage("Cancelled"),
        "captionTitle": MessageLookupByLibrary.simpleMessage("Caption Title"),
        "cardHasExpired":
            MessageLookupByLibrary.simpleMessage("Card has expired"),
        "cardName": MessageLookupByLibrary.simpleMessage("Card Name"),
        "cardNumber": MessageLookupByLibrary.simpleMessage("Card Number"),
        "categories": MessageLookupByLibrary.simpleMessage("Categories"),
        "category": MessageLookupByLibrary.simpleMessage("Category"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Change Password"),
        "checkYourEmail":
            MessageLookupByLibrary.simpleMessage("Check Your Email"),
        "chooseYourCountryCode":
            MessageLookupByLibrary.simpleMessage("Choose your country code"),
        "clearHistory": MessageLookupByLibrary.simpleMessage("Clear History"),
        "closeAccount": MessageLookupByLibrary.simpleMessage("Close Account"),
        "color": MessageLookupByLibrary.simpleMessage("Color"),
        "comments30": MessageLookupByLibrary.simpleMessage("Comments (30)"),
        "confPassword":
            MessageLookupByLibrary.simpleMessage("Confirm Password"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("Confirm Password"),
        "connect": MessageLookupByLibrary.simpleMessage("Connect"),
        "connectTimeout":
            MessageLookupByLibrary.simpleMessage("Connect timeout"),
        "connected": MessageLookupByLibrary.simpleMessage("Connected"),
        "connectionProblem": MessageLookupByLibrary.simpleMessage(
            "There are some problems with the connection. Please try again"),
        "connectionTimedOut": MessageLookupByLibrary.simpleMessage(
            "The connection has timed out. Please try again"),
        "connectionTimeoutWithServer": MessageLookupByLibrary.simpleMessage(
            "Connection timeout with server"),
        "connectionToServerFailedDueToInternetConnection":
            MessageLookupByLibrary.simpleMessage(
                "Connection to server failed due to internet connection."),
        "contactUs": MessageLookupByLibrary.simpleMessage("Contact Us"),
        "continueAsAGuest":
            MessageLookupByLibrary.simpleMessage("Continue as a guest"),
        "createPost": MessageLookupByLibrary.simpleMessage("Create Post"),
        "createStory": MessageLookupByLibrary.simpleMessage("Create Story"),
        "cvv": MessageLookupByLibrary.simpleMessage("Cvv"),
        "cvvIsInvalid": MessageLookupByLibrary.simpleMessage("CVV is invalid"),
        "dashboard": MessageLookupByLibrary.simpleMessage("Dashboard"),
        "dataNotFound": MessageLookupByLibrary.simpleMessage("Data not found"),
        "databaseException":
            MessageLookupByLibrary.simpleMessage("Database exception"),
        "david": MessageLookupByLibrary.simpleMessage("David"),
        "davidMarco": MessageLookupByLibrary.simpleMessage("David Marco"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "dontHaveAccount":
            MessageLookupByLibrary.simpleMessage("Don\"t have an account?"),
        "edit": MessageLookupByLibrary.simpleMessage("Edit"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("Email Address"),
        "emailPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Email / Phone Number"),
        "enterAValidEmailOrPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Enter a valid email or phone number"),
        "enterCardName":
            MessageLookupByLibrary.simpleMessage("Please enter card name"),
        "enterCardNumber":
            MessageLookupByLibrary.simpleMessage("Please enter card number"),
        "enterCvv": MessageLookupByLibrary.simpleMessage("Please enter cvv"),
        "enterExpiryDate":
            MessageLookupByLibrary.simpleMessage("Please enter expiry date"),
        "enterNewPasswordBelow":
            MessageLookupByLibrary.simpleMessage("Enter new password below."),
        "enterYourEmailAddressOrMobileNumberWellSendYou":
            MessageLookupByLibrary.simpleMessage(
                "Enter your email address or mobile number we\'ll send you a link to reset password."),
        "errorDuringCommunication":
            MessageLookupByLibrary.simpleMessage("Error During Communication:"),
        "errorUploadingPhoto":
            MessageLookupByLibrary.simpleMessage("Error uploading photo"),
        "experienceTheRealtime":
            MessageLookupByLibrary.simpleMessage("Experience the realtime"),
        "expiryDate": MessageLookupByLibrary.simpleMessage("Expiry Date"),
        "expiryMonthIsInvalid":
            MessageLookupByLibrary.simpleMessage("Expiry month is invalid"),
        "expiryYearIsInvalid":
            MessageLookupByLibrary.simpleMessage("Expiry year is invalid"),
        "fashionTShirt":
            MessageLookupByLibrary.simpleMessage("Fashion T shirt"),
        "fashionTops": MessageLookupByLibrary.simpleMessage("Fashion Tops"),
        "favorites": MessageLookupByLibrary.simpleMessage("Favorites"),
        "feed": MessageLookupByLibrary.simpleMessage("Feed"),
        "fillDetails": MessageLookupByLibrary.simpleMessage(
            "Fill your below detail to create account"),
        "findPeople": MessageLookupByLibrary.simpleMessage("Find People"),
        "findThingsYoullLove":
            MessageLookupByLibrary.simpleMessage("Find Things You’ll Love"),
        "firstName": MessageLookupByLibrary.simpleMessage("First Name"),
        "follow": MessageLookupByLibrary.simpleMessage("Follow"),
        "followed": MessageLookupByLibrary.simpleMessage("Followed"),
        "followers": MessageLookupByLibrary.simpleMessage("Followers"),
        "following": MessageLookupByLibrary.simpleMessage("Following"),
        "followings": MessageLookupByLibrary.simpleMessage("Followings"),
        "forgot": MessageLookupByLibrary.simpleMessage("Forgot?"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Forgot Password?"),
        "freeShipping": MessageLookupByLibrary.simpleMessage("Free Shipping"),
        "gallery": MessageLookupByLibrary.simpleMessage("Gallery"),
        "gedgets": MessageLookupByLibrary.simpleMessage("Gedgets"),
        "getOtp": MessageLookupByLibrary.simpleMessage("Get OTP"),
        "getStarted": MessageLookupByLibrary.simpleMessage("Get Started"),
        "giftCard": MessageLookupByLibrary.simpleMessage("Gift Card"),
        "good": MessageLookupByLibrary.simpleMessage("Good"),
        "happyShop": MessageLookupByLibrary.simpleMessage("Happy Shop"),
        "hello": MessageLookupByLibrary.simpleMessage("Hello!"),
        "helpCenter": MessageLookupByLibrary.simpleMessage("Help Center"),
        "hi": MessageLookupByLibrary.simpleMessage("Hi,"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "homeLiving": MessageLookupByLibrary.simpleMessage("Home & Living"),
        "iAgree": MessageLookupByLibrary.simpleMessage("I agree to "),
        "iAgreeTo": MessageLookupByLibrary.simpleMessage("I agree to"),
        "invalidCredentials":
            MessageLookupByLibrary.simpleMessage("Invalid credentials"),
        "invalidInput": MessageLookupByLibrary.simpleMessage("Invalid Input:"),
        "invalidRequest":
            MessageLookupByLibrary.simpleMessage("Invalid Request:"),
        "inviteEarn": MessageLookupByLibrary.simpleMessage("Invite & Earn"),
        "itIsALongEstablishedFactThatAReaderWill":
            MessageLookupByLibrary.simpleMessage(
                "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. \n"),
        "kConfPassword": MessageLookupByLibrary.simpleMessage(
            "Please enter confirm password"),
        "kConfirm": MessageLookupByLibrary.simpleMessage("Confirm"),
        "kDeleteAccount": MessageLookupByLibrary.simpleMessage(
            "Are you sure \n\nYou want to delete account?"),
        "kEmptyField": MessageLookupByLibrary.simpleMessage(
            "Please enter email address or mobile number"),
        "kEnterCountryCode":
            MessageLookupByLibrary.simpleMessage("Please enter country code"),
        "kEnterEmailAddress":
            MessageLookupByLibrary.simpleMessage("Please enter email address"),
        "kEnterFirstName":
            MessageLookupByLibrary.simpleMessage("Please enter first name"),
        "kEnterLastName":
            MessageLookupByLibrary.simpleMessage("Please enter last name"),
        "kEnterMobileNumber":
            MessageLookupByLibrary.simpleMessage("Please enter mobile number"),
        "kEnterNewPassword":
            MessageLookupByLibrary.simpleMessage("Please enter new password"),
        "kEnterPassword":
            MessageLookupByLibrary.simpleMessage("Please enter password"),
        "kEnterValidEmailAddress": MessageLookupByLibrary.simpleMessage(
            "Please enter valid email address"),
        "kEnterValidFirstName": MessageLookupByLibrary.simpleMessage(
            "Please enter at least 1 character for first name"),
        "kEnterValidLastName": MessageLookupByLibrary.simpleMessage(
            "Please enter at least 3 characters for last name"),
        "kEnterValidMobileNumber": MessageLookupByLibrary.simpleMessage(
            "Please enter valid mobile number"),
        "kEnterValidPassword": MessageLookupByLibrary.simpleMessage(
            "Password should be 8 or more characters"),
        "kLogoutMsg": MessageLookupByLibrary.simpleMessage(
            "Are you sure \n\nYou want to logout?"),
        "kPleaseEnterOtp":
            MessageLookupByLibrary.simpleMessage("Please enter OTP"),
        "kPleaseEnterValidOtp":
            MessageLookupByLibrary.simpleMessage("Please enter valid OTP"),
        "kids": MessageLookupByLibrary.simpleMessage("Kids"),
        "lastName": MessageLookupByLibrary.simpleMessage("Last Name"),
        "letsCreateYourOwn":
            MessageLookupByLibrary.simpleMessage("Let’s Create your own"),
        "likeNew": MessageLookupByLibrary.simpleMessage("Like New"),
        "logIn": MessageLookupByLibrary.simpleMessage("Log in"),
        "loggedinSuccesfully":
            MessageLookupByLibrary.simpleMessage("LoggedIn succesfully"),
        "login": MessageLookupByLibrary.simpleMessage("Login"),
        "loginToContinue":
            MessageLookupByLibrary.simpleMessage("Login to continue."),
        "logout": MessageLookupByLibrary.simpleMessage("Logout"),
        "looseTexturedTshirt":
            MessageLookupByLibrary.simpleMessage("Loose Textured T-Shirt"),
        "loremIpsumDolorSitAmetConsecrateSadipscingElitrSedDiam":
            MessageLookupByLibrary.simpleMessage(
                "Lorem ipsum dolor sit amet, consecrate sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut"),
        "manageAddresses":
            MessageLookupByLibrary.simpleMessage("Manage Addresses"),
        "manageBillingShippingAddresses": MessageLookupByLibrary.simpleMessage(
            "Manage billing & shipping addresses."),
        "me": MessageLookupByLibrary.simpleMessage("Me"),
        "men": MessageLookupByLibrary.simpleMessage("Men"),
        "messageSentSuccessfully":
            MessageLookupByLibrary.simpleMessage("Message sent successfully"),
        "messages": MessageLookupByLibrary.simpleMessage("Messages"),
        "michael": MessageLookupByLibrary.simpleMessage("Michael"),
        "michaeleLusiada":
            MessageLookupByLibrary.simpleMessage("Michaele Lusiada"),
        "mobNumber": MessageLookupByLibrary.simpleMessage("Mobile Number"),
        "mobile": MessageLookupByLibrary.simpleMessage("Mobile"),
        "mobileNumber": MessageLookupByLibrary.simpleMessage("Mobile Number"),
        "mochaShoes": MessageLookupByLibrary.simpleMessage("Mocha Shoes"),
        "myOrder": MessageLookupByLibrary.simpleMessage("My Order"),
        "myPost": MessageLookupByLibrary.simpleMessage("My Post"),
        "name": MessageLookupByLibrary.simpleMessage("Name"),
        "newCollectionFromBagzag":
            MessageLookupByLibrary.simpleMessage("New Collection from BagZag."),
        "newPassword": MessageLookupByLibrary.simpleMessage("New Password"),
        "no": MessageLookupByLibrary.simpleMessage("No"),
        "noActiveInternetConnection": MessageLookupByLibrary.simpleMessage(
            "No Active Internet Connection"),
        "noProductsFound":
            MessageLookupByLibrary.simpleMessage("No products found!!"),
        "notificationOn":
            MessageLookupByLibrary.simpleMessage("Notification On"),
        "notificationonoff":
            MessageLookupByLibrary.simpleMessage("Notification(On/Off)"),
        "numberIsInvalid":
            MessageLookupByLibrary.simpleMessage("Card is invalid"),
        "ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "or": MessageLookupByLibrary.simpleMessage("Or"),
        "password": MessageLookupByLibrary.simpleMessage("Password"),
        "passwordChangedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Password changed successfully"),
        "passwordConfirmPasswordMustBeSame":
            MessageLookupByLibrary.simpleMessage(
                "Password & confirm password must be same"),
        "passwordMismatch": MessageLookupByLibrary.simpleMessage(
            "Password and Confirm password not match"),
        "passwordUpdatedSuccesfully": MessageLookupByLibrary.simpleMessage(
            "Password updated succesfully"),
        "payment": MessageLookupByLibrary.simpleMessage("payment"),
        "paymentMethods":
            MessageLookupByLibrary.simpleMessage("Payment Methods"),
        "payments": MessageLookupByLibrary.simpleMessage("Payments"),
        "permissionDeniedAlwaysUserNeedToAllowManually":
            MessageLookupByLibrary.simpleMessage(
                "Permission denied always user need to allow manually"),
        "phoneVerification":
            MessageLookupByLibrary.simpleMessage("Phone Verification"),
        "photoPermission":
            MessageLookupByLibrary.simpleMessage("Photo Permission"),
        "pickAudio": MessageLookupByLibrary.simpleMessage("Pick Audio"),
        "pickDocuments": MessageLookupByLibrary.simpleMessage("Pick Documents"),
        "pickImage": MessageLookupByLibrary.simpleMessage("Pick Image"),
        "pickVideo": MessageLookupByLibrary.simpleMessage("Pick Video"),
        "pickedFileCount":
            MessageLookupByLibrary.simpleMessage("Picked file count: "),
        "pleaseAcceptTermsConditions": MessageLookupByLibrary.simpleMessage(
            "Please accept terms & conditions"),
        "pleaseCheckInternetConnection": MessageLookupByLibrary.simpleMessage(
            "Please check internet connection"),
        "pleaseCheckYourInternetConnection":
            MessageLookupByLibrary.simpleMessage(
                "Please check your internet connection"),
        "pleaseEnter4DigitOtp":
            MessageLookupByLibrary.simpleMessage("Please enter 4 digit otp"),
        "pleaseEnter8CharactersPassword": MessageLookupByLibrary.simpleMessage(
            "Please enter 8 characters password"),
        "pleaseEnterCaptionTitle":
            MessageLookupByLibrary.simpleMessage("Please enter caption title"),
        "pleaseEnterCategorySubcategoryBrandDetails":
            MessageLookupByLibrary.simpleMessage(
                "Please enter category, subcategory, brand details"),
        "pleaseEnterConfirmPassword": MessageLookupByLibrary.simpleMessage(
            "Please enter confirm password"),
        "pleaseEnterDescription":
            MessageLookupByLibrary.simpleMessage("Please enter description"),
        "pleaseEnterEmailPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Please enter email / phone number"),
        "pleaseEnterOtp":
            MessageLookupByLibrary.simpleMessage("Please enter otp"),
        "pleaseEnterProductName":
            MessageLookupByLibrary.simpleMessage("Please enter product name"),
        "pleaseEnterSellingPrice":
            MessageLookupByLibrary.simpleMessage("Please enter selling price"),
        "pleaseEnterSubject":
            MessageLookupByLibrary.simpleMessage("Please enter subject"),
        "pleaseEnterTheVerificationCodeWeSentToYourMobile":
            MessageLookupByLibrary.simpleMessage(
                "Please enter the verification code, we sent to your Mobile Number"),
        "pleaseEnterValidPassword":
            MessageLookupByLibrary.simpleMessage("Please enter valid password"),
        "pleaseLoginAgain":
            MessageLookupByLibrary.simpleMessage("Please login again."),
        "post": MessageLookupByLibrary.simpleMessage("Post"),
        "privacyPolicy":
            MessageLookupByLibrary.simpleMessage("Privacy Policy."),
        "products": MessageLookupByLibrary.simpleMessage("Products"),
        "rateApp": MessageLookupByLibrary.simpleMessage("Rate App"),
        "receiveTimeout":
            MessageLookupByLibrary.simpleMessage("Receive timeout"),
        "recentSearches":
            MessageLookupByLibrary.simpleMessage("Recent Searches"),
        "recentlyViewedByYou":
            MessageLookupByLibrary.simpleMessage("Recently viewed By You"),
        "recommendedProducts":
            MessageLookupByLibrary.simpleMessage("Recommended Products"),
        "requestCantBeHandledForNowPleaseTryAfterSometime":
            MessageLookupByLibrary.simpleMessage(
                "Request can\'t be handled for now. Please try after sometime."),
        "requestToServerWasCancelled": MessageLookupByLibrary.simpleMessage(
            "Request to server was cancelled"),
        "resendCode": MessageLookupByLibrary.simpleMessage("Resend Code"),
        "resetPassword": MessageLookupByLibrary.simpleMessage("Reset Password"),
        "responseNull":
            MessageLookupByLibrary.simpleMessage("Response is null"),
        "rubina": MessageLookupByLibrary.simpleMessage("Rubina"),
        "search": MessageLookupByLibrary.simpleMessage("Search..."),
        "seeAllAppSettings":
            MessageLookupByLibrary.simpleMessage("See all app settings"),
        "seeAllProductPostCreatedByYou": MessageLookupByLibrary.simpleMessage(
            "See all product post created by you."),
        "seeLess": MessageLookupByLibrary.simpleMessage("See Less"),
        "seeMore": MessageLookupByLibrary.simpleMessage("See More"),
        "selectYourPhoneCode":
            MessageLookupByLibrary.simpleMessage("Select your phone code"),
        "sell": MessageLookupByLibrary.simpleMessage("Sell"),
        "sendMessage": MessageLookupByLibrary.simpleMessage("Send message"),
        "sendTimeout": MessageLookupByLibrary.simpleMessage("Send timeout"),
        "serverError": MessageLookupByLibrary.simpleMessage("Server error."),
        "serverNotFound":
            MessageLookupByLibrary.simpleMessage("Server not found"),
        "serverUnknownError":
            MessageLookupByLibrary.simpleMessage("Server unknown error"),
        "settings": MessageLookupByLibrary.simpleMessage("Settings"),
        "sevenSennseStore":
            MessageLookupByLibrary.simpleMessage("Seven Sennse Store"),
        "shareApp": MessageLookupByLibrary.simpleMessage("Share App"),
        "shares": MessageLookupByLibrary.simpleMessage("Shares"),
        "sharingSettings":
            MessageLookupByLibrary.simpleMessage("Sharing Settings"),
        "shopProducts": MessageLookupByLibrary.simpleMessage("Shop Products"),
        "signIn": MessageLookupByLibrary.simpleMessage("Sign In"),
        "signInTo": MessageLookupByLibrary.simpleMessage("SIgn In to"),
        "signInWith": MessageLookupByLibrary.simpleMessage("Sign In With"),
        "signUp": MessageLookupByLibrary.simpleMessage("Sign up"),
        "size": MessageLookupByLibrary.simpleMessage("Size"),
        "skip": MessageLookupByLibrary.simpleMessage("Skip"),
        "somethingWentWrongPleaseTryAfterSometime":
            MessageLookupByLibrary.simpleMessage(
                "Something went wrong. Please try after sometime."),
        "somethingWhenWrongPleaseTryAgain":
            MessageLookupByLibrary.simpleMessage(
                "Something when wrong. Please try again."),
        "sports": MessageLookupByLibrary.simpleMessage("Sports"),
        "store": MessageLookupByLibrary.simpleMessage("Store"),
        "studio": MessageLookupByLibrary.simpleMessage("Studio"),
        "style": MessageLookupByLibrary.simpleMessage("style"),
        "subcategory": MessageLookupByLibrary.simpleMessage("Subcategory"),
        "subject": MessageLookupByLibrary.simpleMessage("Subject"),
        "submit": MessageLookupByLibrary.simpleMessage("Submit"),
        "tNc": MessageLookupByLibrary.simpleMessage("Terms & Conditions"),
        "termsCondition":
            MessageLookupByLibrary.simpleMessage("Terms & Condition"),
        "termsOfUse": MessageLookupByLibrary.simpleMessage("Terms of Use"),
        "thankyou": MessageLookupByLibrary.simpleMessage("ThankYou!!"),
        "theLibas": MessageLookupByLibrary.simpleMessage("The Libas"),
        "theNewShop": MessageLookupByLibrary.simpleMessage("The New Shop"),
        "theNewStore": MessageLookupByLibrary.simpleMessage("The New Store"),
        "toyBaby": MessageLookupByLibrary.simpleMessage("Toy & Baby"),
        "trackOrder": MessageLookupByLibrary.simpleMessage("Track Order"),
        "tracking": MessageLookupByLibrary.simpleMessage("Tracking"),
        "trendyCollection":
            MessageLookupByLibrary.simpleMessage("Trendy Collection"),
        "unauthorised": MessageLookupByLibrary.simpleMessage("Unauthorised:"),
        "unknownError": MessageLookupByLibrary.simpleMessage("Unknown error"),
        "update": MessageLookupByLibrary.simpleMessage("Update"),
        "userAllowedToAccessPhotos": MessageLookupByLibrary.simpleMessage(
            "User Allowed to access photos"),
        "userDeniedToAccessPhotos": MessageLookupByLibrary.simpleMessage(
            "User Denied to access photos"),
        "verify": MessageLookupByLibrary.simpleMessage("Verify"),
        "viewMore": MessageLookupByLibrary.simpleMessage("View More"),
        "weHaveSentInstructionsOnHowToResetThePassword":
            MessageLookupByLibrary.simpleMessage(
                "We have sent instructions on how to reset the password."),
        "welComeBack": MessageLookupByLibrary.simpleMessage("Welcome back!"),
        "welcomeBack": MessageLookupByLibrary.simpleMessage("Welcome Back!"),
        "women": MessageLookupByLibrary.simpleMessage("Women"),
        "yes": MessageLookupByLibrary.simpleMessage("Yes"),
        "youCanAddremovePaymentMethods": MessageLookupByLibrary.simpleMessage(
            "You can add/remove payment methods."),
        "youCanChangeThePasswordForSecurityPurpose":
            MessageLookupByLibrary.simpleMessage(
                "You can change the password for security purpose."),
        "youCanInviteOtherUserEarnMoney": MessageLookupByLibrary.simpleMessage(
            "You can invite other user & earn money."),
        "youCanSearchPeopleWhoAreUsingTheApp":
            MessageLookupByLibrary.simpleMessage(
                "You can search people who are using the app"),
        "youCanSeeAllBookmarkPost": MessageLookupByLibrary.simpleMessage(
            "You can see all bookmark post."),
        "youCanSeeAllPendingAndPastOrders":
            MessageLookupByLibrary.simpleMessage(
                "You can see all pending and past orders."),
        "youCanSeeBrandedStore":
            MessageLookupByLibrary.simpleMessage("You can see branded store."),
        "youCanSeeListOfYourMessages": MessageLookupByLibrary.simpleMessage(
            "You can see list of your messages"),
        "youCanSendGiftToOther":
            MessageLookupByLibrary.simpleMessage("You can send gift to other"),
        "yourPostUploadedSuccessfully": MessageLookupByLibrary.simpleMessage(
            "Your post uploaded successfully")
      };
}
