// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

part of 'app_router.dart';

abstract class _$AppRouter extends RootStackRouter {
  // ignore: unused_element
  _$AppRouter({super.navigatorKey});

  @override
  final Map<String, PageFactory> pagesMap = {
    AboutUsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const AboutUsPage(),
      );
    },
    AddProductInfoRoute.name: (routeData) {
      final args = routeData.argsAs<AddProductInfoRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: AddProductInfoPage(
          path: args.path,
        ),
      );
    },
    AppBarSearchRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const AppBarSearchPage(),
      );
    },
    BagzagMallRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const BagzagMallPage(),
      );
    },
    BottomNavigationBarRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const BottomNavigationBarPage(),
      );
    },
    BrowseCategoriesRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const BrowseCategoriesPage(),
      );
    },
    CategoriesDetailsRoute.name: (routeData) {
      final args = routeData.argsAs<CategoriesDetailsRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: CategoriesDetailsPage(
          image: args.image,
          categoryName: args.categoryName,
          index: args.index,
        ),
      );
    },
    ChangePasswordRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ChangePasswordPage(),
      );
    },
    ContactUsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ContactUsPage(),
      );
    },
    CreateAccountRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const CreateAccountPage(),
      );
    },
    CreatePostBrandDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const CreatePostBrandDetailsPage(),
      );
    },
    CreatePostCategoryDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const CreatePostCategoryDetailsPage(),
      );
    },
    CreatePostColorDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const CreatePostColorDetailsPage(),
      );
    },
    CreatePostSizeDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const CreatePostSizeDetailsPage(),
      );
    },
    CreatePostSubCategoryDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const CreatePostSubCategoryDetailsPage(),
      );
    },
    CreateStoryRoute.name: (routeData) {
      final args = routeData.argsAs<CreateStoryRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: CreateStoryPage(
          path: args.path,
        ),
      );
    },
    FavoritesRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const FavoritesPage(),
      );
    },
    ForgotPasswordRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ForgotPasswordPage(),
      );
    },
    HomeRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const HomePage(),
      );
    },
    InfluencerProfileRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const InfluencerProfilePage(),
      );
    },
    MallDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const MallDetailsPage(),
      );
    },
    PhoneVerificationRoute.name: (routeData) {
      final args = routeData.argsAs<PhoneVerificationRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: PhoneVerificationPage(
          checked: args.checked,
        ),
      );
    },
    PolicyRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const PolicyPage(),
      );
    },
    PostedProductDetailsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const PostedProductDetailsPage(),
      );
    },
    ProfileRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ProfilePage(),
      );
    },
    ResetPasswordRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ResetPasswordPage(),
      );
    },
    SearchedProductViewRoute.name: (routeData) {
      final args = routeData.argsAs<SearchedProductViewRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: SearchedProductViewPage(
          productName: args.productName,
        ),
      );
    },
    SellRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SellPage(),
      );
    },
    SettingRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SettingPage(),
      );
    },
    SharedSettingRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SharedSettingPage(),
      );
    },
    SplashRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const SplashPage(),
      );
    },
    StoryViewRoute.name: (routeData) {
      final args = routeData.argsAs<StoryViewRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: StoryViewPage(
          data: args.data,
        ),
      );
    },
    TermsRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const TermsPage(),
      );
    },
    WalkThroughRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const WalkThroughPage(),
      );
    },
  };
}

/// generated route for
/// [AboutUsPage]
class AboutUsRoute extends PageRouteInfo<void> {
  const AboutUsRoute({List<PageRouteInfo>? children})
      : super(
          AboutUsRoute.name,
          initialChildren: children,
        );

  static const String name = 'AboutUsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [AddProductInfoPage]
class AddProductInfoRoute extends PageRouteInfo<AddProductInfoRouteArgs> {
  AddProductInfoRoute({
    Key? key,
    required String path,
    List<PageRouteInfo>? children,
  }) : super(
          AddProductInfoRoute.name,
          args: AddProductInfoRouteArgs(
            key: key,
            path: path,
          ),
          initialChildren: children,
        );

  static const String name = 'AddProductInfoRoute';

  static const PageInfo<AddProductInfoRouteArgs> page =
      PageInfo<AddProductInfoRouteArgs>(name);
}

class AddProductInfoRouteArgs {
  const AddProductInfoRouteArgs({
    this.key,
    required this.path,
  });

  final Key? key;

  final String path;

  @override
  String toString() {
    return 'AddProductInfoRouteArgs{key: $key, path: $path}';
  }
}

/// generated route for
/// [AppBarSearchPage]
class AppBarSearchRoute extends PageRouteInfo<void> {
  const AppBarSearchRoute({List<PageRouteInfo>? children})
      : super(
          AppBarSearchRoute.name,
          initialChildren: children,
        );

  static const String name = 'AppBarSearchRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [BagzagMallPage]
class BagzagMallRoute extends PageRouteInfo<void> {
  const BagzagMallRoute({List<PageRouteInfo>? children})
      : super(
          BagzagMallRoute.name,
          initialChildren: children,
        );

  static const String name = 'BagzagMallRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [BottomNavigationBarPage]
class BottomNavigationBarRoute extends PageRouteInfo<void> {
  const BottomNavigationBarRoute({List<PageRouteInfo>? children})
      : super(
          BottomNavigationBarRoute.name,
          initialChildren: children,
        );

  static const String name = 'BottomNavigationBarRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [BrowseCategoriesPage]
class BrowseCategoriesRoute extends PageRouteInfo<void> {
  const BrowseCategoriesRoute({List<PageRouteInfo>? children})
      : super(
          BrowseCategoriesRoute.name,
          initialChildren: children,
        );

  static const String name = 'BrowseCategoriesRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CategoriesDetailsPage]
class CategoriesDetailsRoute extends PageRouteInfo<CategoriesDetailsRouteArgs> {
  CategoriesDetailsRoute({
    Key? key,
    required String image,
    required String categoryName,
    required int index,
    List<PageRouteInfo>? children,
  }) : super(
          CategoriesDetailsRoute.name,
          args: CategoriesDetailsRouteArgs(
            key: key,
            image: image,
            categoryName: categoryName,
            index: index,
          ),
          initialChildren: children,
        );

  static const String name = 'CategoriesDetailsRoute';

  static const PageInfo<CategoriesDetailsRouteArgs> page =
      PageInfo<CategoriesDetailsRouteArgs>(name);
}

class CategoriesDetailsRouteArgs {
  const CategoriesDetailsRouteArgs({
    this.key,
    required this.image,
    required this.categoryName,
    required this.index,
  });

  final Key? key;

  final String image;

  final String categoryName;

  final int index;

  @override
  String toString() {
    return 'CategoriesDetailsRouteArgs{key: $key, image: $image, categoryName: $categoryName, index: $index}';
  }
}

/// generated route for
/// [ChangePasswordPage]
class ChangePasswordRoute extends PageRouteInfo<void> {
  const ChangePasswordRoute({List<PageRouteInfo>? children})
      : super(
          ChangePasswordRoute.name,
          initialChildren: children,
        );

  static const String name = 'ChangePasswordRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ContactUsPage]
class ContactUsRoute extends PageRouteInfo<void> {
  const ContactUsRoute({List<PageRouteInfo>? children})
      : super(
          ContactUsRoute.name,
          initialChildren: children,
        );

  static const String name = 'ContactUsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CreateAccountPage]
class CreateAccountRoute extends PageRouteInfo<void> {
  const CreateAccountRoute({List<PageRouteInfo>? children})
      : super(
          CreateAccountRoute.name,
          initialChildren: children,
        );

  static const String name = 'CreateAccountRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CreatePostBrandDetailsPage]
class CreatePostBrandDetailsRoute extends PageRouteInfo<void> {
  const CreatePostBrandDetailsRoute({List<PageRouteInfo>? children})
      : super(
          CreatePostBrandDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'CreatePostBrandDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CreatePostCategoryDetailsPage]
class CreatePostCategoryDetailsRoute extends PageRouteInfo<void> {
  const CreatePostCategoryDetailsRoute({List<PageRouteInfo>? children})
      : super(
          CreatePostCategoryDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'CreatePostCategoryDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CreatePostColorDetailsPage]
class CreatePostColorDetailsRoute extends PageRouteInfo<void> {
  const CreatePostColorDetailsRoute({List<PageRouteInfo>? children})
      : super(
          CreatePostColorDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'CreatePostColorDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CreatePostSizeDetailsPage]
class CreatePostSizeDetailsRoute extends PageRouteInfo<void> {
  const CreatePostSizeDetailsRoute({List<PageRouteInfo>? children})
      : super(
          CreatePostSizeDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'CreatePostSizeDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CreatePostSubCategoryDetailsPage]
class CreatePostSubCategoryDetailsRoute extends PageRouteInfo<void> {
  const CreatePostSubCategoryDetailsRoute({List<PageRouteInfo>? children})
      : super(
          CreatePostSubCategoryDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'CreatePostSubCategoryDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [CreateStoryPage]
class CreateStoryRoute extends PageRouteInfo<CreateStoryRouteArgs> {
  CreateStoryRoute({
    Key? key,
    required String path,
    List<PageRouteInfo>? children,
  }) : super(
          CreateStoryRoute.name,
          args: CreateStoryRouteArgs(
            key: key,
            path: path,
          ),
          initialChildren: children,
        );

  static const String name = 'CreateStoryRoute';

  static const PageInfo<CreateStoryRouteArgs> page =
      PageInfo<CreateStoryRouteArgs>(name);
}

class CreateStoryRouteArgs {
  const CreateStoryRouteArgs({
    this.key,
    required this.path,
  });

  final Key? key;

  final String path;

  @override
  String toString() {
    return 'CreateStoryRouteArgs{key: $key, path: $path}';
  }
}

/// generated route for
/// [FavoritesPage]
class FavoritesRoute extends PageRouteInfo<void> {
  const FavoritesRoute({List<PageRouteInfo>? children})
      : super(
          FavoritesRoute.name,
          initialChildren: children,
        );

  static const String name = 'FavoritesRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ForgotPasswordPage]
class ForgotPasswordRoute extends PageRouteInfo<void> {
  const ForgotPasswordRoute({List<PageRouteInfo>? children})
      : super(
          ForgotPasswordRoute.name,
          initialChildren: children,
        );

  static const String name = 'ForgotPasswordRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [HomePage]
class HomeRoute extends PageRouteInfo<void> {
  const HomeRoute({List<PageRouteInfo>? children})
      : super(
          HomeRoute.name,
          initialChildren: children,
        );

  static const String name = 'HomeRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [InfluencerProfilePage]
class InfluencerProfileRoute extends PageRouteInfo<void> {
  const InfluencerProfileRoute({List<PageRouteInfo>? children})
      : super(
          InfluencerProfileRoute.name,
          initialChildren: children,
        );

  static const String name = 'InfluencerProfileRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [MallDetailsPage]
class MallDetailsRoute extends PageRouteInfo<void> {
  const MallDetailsRoute({List<PageRouteInfo>? children})
      : super(
          MallDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'MallDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [PhoneVerificationPage]
class PhoneVerificationRoute extends PageRouteInfo<PhoneVerificationRouteArgs> {
  PhoneVerificationRoute({
    Key? key,
    required bool checked,
    List<PageRouteInfo>? children,
  }) : super(
          PhoneVerificationRoute.name,
          args: PhoneVerificationRouteArgs(
            key: key,
            checked: checked,
          ),
          initialChildren: children,
        );

  static const String name = 'PhoneVerificationRoute';

  static const PageInfo<PhoneVerificationRouteArgs> page =
      PageInfo<PhoneVerificationRouteArgs>(name);
}

class PhoneVerificationRouteArgs {
  const PhoneVerificationRouteArgs({
    this.key,
    required this.checked,
  });

  final Key? key;

  final bool checked;

  @override
  String toString() {
    return 'PhoneVerificationRouteArgs{key: $key, checked: $checked}';
  }
}

/// generated route for
/// [PolicyPage]
class PolicyRoute extends PageRouteInfo<void> {
  const PolicyRoute({List<PageRouteInfo>? children})
      : super(
          PolicyRoute.name,
          initialChildren: children,
        );

  static const String name = 'PolicyRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [PostedProductDetailsPage]
class PostedProductDetailsRoute extends PageRouteInfo<void> {
  const PostedProductDetailsRoute({List<PageRouteInfo>? children})
      : super(
          PostedProductDetailsRoute.name,
          initialChildren: children,
        );

  static const String name = 'PostedProductDetailsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ProfilePage]
class ProfileRoute extends PageRouteInfo<void> {
  const ProfileRoute({List<PageRouteInfo>? children})
      : super(
          ProfileRoute.name,
          initialChildren: children,
        );

  static const String name = 'ProfileRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ResetPasswordPage]
class ResetPasswordRoute extends PageRouteInfo<void> {
  const ResetPasswordRoute({List<PageRouteInfo>? children})
      : super(
          ResetPasswordRoute.name,
          initialChildren: children,
        );

  static const String name = 'ResetPasswordRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SearchedProductViewPage]
class SearchedProductViewRoute
    extends PageRouteInfo<SearchedProductViewRouteArgs> {
  SearchedProductViewRoute({
    Key? key,
    required String productName,
    List<PageRouteInfo>? children,
  }) : super(
          SearchedProductViewRoute.name,
          args: SearchedProductViewRouteArgs(
            key: key,
            productName: productName,
          ),
          initialChildren: children,
        );

  static const String name = 'SearchedProductViewRoute';

  static const PageInfo<SearchedProductViewRouteArgs> page =
      PageInfo<SearchedProductViewRouteArgs>(name);
}

class SearchedProductViewRouteArgs {
  const SearchedProductViewRouteArgs({
    this.key,
    required this.productName,
  });

  final Key? key;

  final String productName;

  @override
  String toString() {
    return 'SearchedProductViewRouteArgs{key: $key, productName: $productName}';
  }
}

/// generated route for
/// [SellPage]
class SellRoute extends PageRouteInfo<void> {
  const SellRoute({List<PageRouteInfo>? children})
      : super(
          SellRoute.name,
          initialChildren: children,
        );

  static const String name = 'SellRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SettingPage]
class SettingRoute extends PageRouteInfo<void> {
  const SettingRoute({List<PageRouteInfo>? children})
      : super(
          SettingRoute.name,
          initialChildren: children,
        );

  static const String name = 'SettingRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SharedSettingPage]
class SharedSettingRoute extends PageRouteInfo<void> {
  const SharedSettingRoute({List<PageRouteInfo>? children})
      : super(
          SharedSettingRoute.name,
          initialChildren: children,
        );

  static const String name = 'SharedSettingRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [SplashPage]
class SplashRoute extends PageRouteInfo<void> {
  const SplashRoute({List<PageRouteInfo>? children})
      : super(
          SplashRoute.name,
          initialChildren: children,
        );

  static const String name = 'SplashRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [StoryViewPage]
class StoryViewRoute extends PageRouteInfo<StoryViewRouteArgs> {
  StoryViewRoute({
    Key? key,
    required FeedStoryData data,
    List<PageRouteInfo>? children,
  }) : super(
          StoryViewRoute.name,
          args: StoryViewRouteArgs(
            key: key,
            data: data,
          ),
          initialChildren: children,
        );

  static const String name = 'StoryViewRoute';

  static const PageInfo<StoryViewRouteArgs> page =
      PageInfo<StoryViewRouteArgs>(name);
}

class StoryViewRouteArgs {
  const StoryViewRouteArgs({
    this.key,
    required this.data,
  });

  final Key? key;

  final FeedStoryData data;

  @override
  String toString() {
    return 'StoryViewRouteArgs{key: $key, data: $data}';
  }
}

/// generated route for
/// [TermsPage]
class TermsRoute extends PageRouteInfo<void> {
  const TermsRoute({List<PageRouteInfo>? children})
      : super(
          TermsRoute.name,
          initialChildren: children,
        );

  static const String name = 'TermsRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [WalkThroughPage]
class WalkThroughRoute extends PageRouteInfo<void> {
  const WalkThroughRoute({List<PageRouteInfo>? children})
      : super(
          WalkThroughRoute.name,
          initialChildren: children,
        );

  static const String name = 'WalkThroughRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}
