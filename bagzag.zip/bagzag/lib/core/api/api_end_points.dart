abstract class APIEndPoints {
  APIEndPoints._();
  static String baseUrl = 'https://www.dummy.com/';
  static String login = 'user/login';
}
