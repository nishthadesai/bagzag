import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';

@RoutePage()
class PostedProductDetailsPage extends StatefulWidget {
  const PostedProductDetailsPage({super.key});

  @override
  State<PostedProductDetailsPage> createState() =>
      _PostedProductDetailsPageState();
}

class _PostedProductDetailsPageState extends State<PostedProductDetailsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
